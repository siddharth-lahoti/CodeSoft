document.addEventListener('DOMContentLoaded', () => {
  new Calculator();
})